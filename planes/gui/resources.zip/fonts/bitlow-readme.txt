This font is unlicensed and can be used freely.

This font is designed to be used at a certain size.
The preferred size is showed in the style field in your software(Photoshop, Paint Shop Pro etc.)
If you want the font bigger i recommend you to use the standard size and then resize the image.

If you dont see any characters when using the font, try upper or lower caps.